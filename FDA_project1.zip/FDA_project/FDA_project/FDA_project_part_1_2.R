# FMCG Supply Chain Analytics - PART 1: DATA LOADING & EDA
library(tidyverse)
library(ggplot2)
library(dplyr)
library(lubridate)
library(scales)
supply_chain <- read.csv("/Users/abishekbalaji/Downloads/DataCoSupplyChainDataset_cleaned_columns.csv", 
                         stringsAsFactors = FALSE)
cat("Dataset loaded successfully!\n\n")

# Display basic information
cat("DATASET DIMENSIONS:\n")
cat("  Rows:", nrow(supply_chain), "\n")
cat("  Columns:", ncol(supply_chain), "\n\n")

cat("COLUMN NAMES (All 53 columns):\n")
print(colnames(supply_chain))

cat("\n\nDATA TYPES:\n")
print(str(supply_chain))

# STEP 2: DATA CLEANING & PREPROCESSING
cat("\n\nSTEP 2: DATA CLEANING AND PREPROCESSING\n")
cat("-", rep("-", 76), "\n\n")

# Create a working copy
df <- supply_chain
cat("Converting date columns...\n")
# For order_date_dateorders_ format: "m/d/yyyy HH:MM"
# Use parse_date_time for more flexible parsing
df$order_date_dateorders_ <- parse_date_time(df$order_date_dateorders_, 
                                             orders = "mdy_HM")

# For shipping_date_dateorders_ format: "yyyy-mm-dd"
df$shipping_date_dateorders_ <- as.Date(df$shipping_date_dateorders_, 
                                        format = "%Y-%m-%d")

cat("✓ Dates converted successfully\n\n")

# Verify date conversion
cat("Date conversion verification:\n")
cat("  First order date:", as.character(df$order_date_dateorders_[1]), "\n")
cat("  First shipping date:", as.character(df$shipping_date_dateorders_[1]), "\n\n")

# ============ Calculate Lead Time ============
cat("Calculating lead time (Days from Order to Ship)...\n")

df$lead_time <- as.numeric(difftime(df$shipping_date_dateorders_, 
                                    df$order_date_dateorders_, 
                                    units = "days"))

cat("Lead time statistics (before cleaning):\n")
print(summary(df$lead_time))

# Identify and handle problematic lead times
negative_lt <- sum(df$lead_time < 0, na.rm = TRUE)
missing_lt <- sum(is.na(df$lead_time))
very_long_lt <- sum(df$lead_time > 365, na.rm = TRUE)

cat("\nProblematic lead times:\n")
cat("  Negative lead times:", negative_lt, "\n")
cat("  Missing lead times (NA):", missing_lt, "\n")
cat("  Lead times > 365 days:", very_long_lt, "\n\n")

# Replace problematic values with NA
df$lead_time[df$lead_time < 0] <- NA
df$lead_time[df$lead_time > 365] <- NA

# ============ Convert late_delivery_risk ============
cat("Converting late_delivery_risk to numeric...\n")
df$late_delivery_risk <- as.numeric(df$late_delivery_risk == 1)
# STEP 3: DATA VALIDATION & CLEANING
cat("\nSTEP 3: DATA VALIDATION\n")
cat("-", rep("-", 76), "\n\n")

# Check for missing values in critical columns
cat("Missing values in critical columns:\n")
critical_cols <- c("lead_time", "late_delivery_risk", "order_item_quantity",
                   "order_region", "category_name", "shipping_mode")

for (col in critical_cols) {
  if (col %in% colnames(df)) {
    missing_count <- sum(is.na(df[[col]]))
    cat(sprintf("  %s: %d (%.2f%%)\n", col, missing_count, 
                (missing_count/nrow(df))*100))
  }
}

# Remove rows with missing critical values
df_clean <- df %>%
  filter(!is.na(lead_time),
         !is.na(late_delivery_risk),
         !is.na(order_item_quantity))

cat("\n\nDATA CLEANING SUMMARY:\n")
cat(sprintf("  Original rows: %d\n", nrow(df)))
cat(sprintf("  Cleaned rows: %d\n", nrow(df_clean)))
cat(sprintf("  Removed rows: %d (%.2f%%)\n", 
            nrow(df) - nrow(df_clean),
            ((nrow(df) - nrow(df_clean)) / nrow(df)) * 100))


# STEP 4: DESCRIPTIVE STATISTICS
cat("\n\nSTEP 4: DESCRIPTIVE STATISTICS\n")
cat("-", rep("-", 76), "\n\n")

# Lead Time Statistics
cat("LEAD TIME ANALYSIS:\n")
cat("  Mean:", round(mean(df_clean$lead_time, na.rm = TRUE), 2), "days\n")
cat("  Median:", round(median(df_clean$lead_time, na.rm = TRUE), 2), "days\n")
cat("  Std Dev:", round(sd(df_clean$lead_time, na.rm = TRUE), 2), "days\n")
cat("  Min:", round(min(df_clean$lead_time, na.rm = TRUE), 2), "days\n")
cat("  Max:", round(max(df_clean$lead_time, na.rm = TRUE), 2), "days\n")
cat("  Q1:", round(quantile(df_clean$lead_time, 0.25, na.rm = TRUE), 2), "days\n")
cat("  Q3:", round(quantile(df_clean$lead_time, 0.75, na.rm = TRUE), 2), "days\n\n")

# Order Quantity Statistics
cat("ORDER QUANTITY ANALYSIS:\n")
cat("  Mean:", round(mean(df_clean$order_item_quantity, na.rm = TRUE), 2), "\n")
cat("  Median:", round(median(df_clean$order_item_quantity, na.rm = TRUE), 2), "\n")
cat("  Std Dev:", round(sd(df_clean$order_item_quantity, na.rm = TRUE), 2), "\n")
cat("  Min:", round(min(df_clean$order_item_quantity, na.rm = TRUE), 2), "\n")
cat("  Max:", round(max(df_clean$order_item_quantity, na.rm = TRUE), 2), "\n\n")

# Late Delivery Risk
cat("LATE DELIVERY RISK:\n")
late_count <- sum(df_clean$late_delivery_risk == 1, na.rm = TRUE)
no_late_count <- sum(df_clean$late_delivery_risk == 0, na.rm = TRUE)
late_rate <- (late_count / nrow(df_clean)) * 100
cat(sprintf("  Total orders: %d\n", nrow(df_clean)))
cat(sprintf("  Late deliveries: %d (%.2f%%)\n", late_count, late_rate))
cat(sprintf("  On-time deliveries: %d (%.2f%%)\n", no_late_count, 100 - late_rate))

# Shipping Mode Distribution
cat("\n\nSHIPPING MODE DISTRIBUTION:\n")
shipping_dist <- table(df_clean$shipping_mode)
print(shipping_dist)

# Order Region Distribution
cat("\n\nORDER REGION DISTRIBUTION:\n")
region_dist <- table(df_clean$order_region)
print(region_dist)

# Category Name Distribution
cat("\n\nPRODUCT CATEGORY DISTRIBUTION:\n")
category_dist <- table(df_clean$category_name)
print(head(category_dist, 10))  # Top 10

# Delivery Status Distribution
cat("\n\nDELIVERY STATUS DISTRIBUTION:\n")
delivery_status_dist <- table(df_clean$delivery_status)
print(delivery_status_dist)

# Order Status Distribution
cat("\n\nORDER STATUS DISTRIBUTION:\n")
order_status_dist <- table(df_clean$order_status)
print(head(order_status_dist, 10))  # Top 10


# STEP 5: KEY INSIGHTS FROM DATA
cat("\n\nSTEP 5: KEY INSIGHTS\n")
cat("-", rep("-", 76), "\n\n")

# Lead time by shipping mode
lead_by_shipping <- df_clean %>%
  group_by(shipping_mode) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    std_lead_time = sd(lead_time, na.rm = TRUE),
    count = n(),
    .groups = 'drop'
  ) %>%
  arrange(avg_lead_time)

cat("AVERAGE LEAD TIME BY SHIPPING MODE:\n")
print(lead_by_shipping)

# Late delivery risk by shipping mode
risk_by_shipping <- df_clean %>%
  group_by(shipping_mode) %>%
  summarise(
    late_risk_pct = mean(late_delivery_risk, na.rm = TRUE) * 100,
    total_orders = n(),
    .groups = 'drop'
  ) %>%
  arrange(desc(late_risk_pct))

cat("\n\nLATE DELIVERY RISK BY SHIPPING MODE:\n")
print(risk_by_shipping)

# Lead time by region
lead_by_region <- df_clean %>%
  group_by(order_region) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    std_lead_time = sd(lead_time, na.rm = TRUE),
    late_risk_pct = mean(late_delivery_risk, na.rm = TRUE) * 100,
    count = n(),
    .groups = 'drop'
  ) %>%
  arrange(desc(avg_lead_time))

cat("\n\nLEAD TIME AND RISK BY REGION (Top 10):\n")
print(head(lead_by_region, 10))


# STEP 6: SAVE CLEANED DATA


cat("\n\nSTEP 6: SAVING CLEANED DATA\n")
cat("-", rep("-", 76), "\n\n")

# Save cleaned data as RDS for next parts
saveRDS(df_clean, "supply_chain_cleaned.rds")
cat("✓ Cleaned data saved to: supply_chain_cleaned.rds\n")

# Save summary statistics to CSV
summary_stats <- data.frame(
  Metric = c(
    "Total Orders",
    "Average Lead Time (days)",
    "Std Dev Lead Time",
    "Lead Time Min",
    "Lead Time Max",
    "Late Delivery Rate (%)",
    "Number of Regions",
    "Number of Categories",
    "Number of Shipping Modes"
  ),
  Value = c(
    nrow(df_clean),
    round(mean(df_clean$lead_time, na.rm = TRUE), 2),
    round(sd(df_clean$lead_time, na.rm = TRUE), 2),
    round(min(df_clean$lead_time, na.rm = TRUE), 2),
    round(max(df_clean$lead_time, na.rm = TRUE), 2),
    round(late_rate, 2),
    n_distinct(df_clean$order_region),
    n_distinct(df_clean$category_name),
    n_distinct(df_clean$shipping_mode)
  )
)

write.csv(summary_stats, "data_summary_statistics.csv", row.names = FALSE)
cat("✓ Summary statistics saved to: data_summary_statistics.csv\n")

# Save detailed regional analysis
write.csv(lead_by_region, "regional_analysis.csv", row.names = FALSE)
cat("✓ Regional analysis saved to: regional_analysis.csv\n")

# Save shipping mode analysis
write.csv(lead_by_shipping, "shipping_mode_analysis.csv", row.names = FALSE)
cat("✓ Shipping mode analysis saved to: shipping_mode_analysis.csv\n")


# STEP 7: FINAL SUMMARY
cat("Summary of cleaned dataset:\n")
print(summary_stats)
cat("\n\nFiles generated:\n")
cat("  1. supply_chain_cleaned.rds (cleaned dataset)\n")
cat("  2. data_summary_statistics.csv\n")
cat("  3. regional_analysis.csv\n")
cat("  4. shipping_mode_analysis.csv\n")



# FMCG Supply Chain Analytics - PART 2: COMPREHENSIVE VISUALIZATIONS
library(tidyverse)
library(ggplot2)
library(gridExtra)
library(scales)

# Load cleaned data from Part 1
df_clean <- readRDS("supply_chain_cleaned.rds")

cat("✓ Cleaned data loaded\n")
cat("  Rows:", nrow(df_clean), "\n")
cat("  Columns:", ncol(df_clean), "\n\n")

# Set ggplot theme for better aesthetics
theme_set(theme_minimal() + theme(
  plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
  plot.subtitle = element_text(size = 11, hjust = 0.5),
  axis.title = element_text(size = 11, face = "bold"),
  legend.position = "bottom",
  panel.grid.major = element_line(color = "gray90"),
  panel.grid.minor = element_blank()
))

cat("Generating visualizations...\n\n")


#Average Lead Time by Region
cat("VIZ 1: Average Lead Time by Region\n")

viz1 <- df_clean %>%
  group_by(order_region) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    std_lead_time = sd(lead_time, na.rm = TRUE),
    count = n(),
    .groups = 'drop'
  ) %>%
  arrange(desc(avg_lead_time)) %>%
  ggplot(aes(x = reorder(order_region, -avg_lead_time), 
             y = avg_lead_time, fill = avg_lead_time)) +
  geom_col(alpha = 0.8) +
  geom_errorbar(aes(ymin = avg_lead_time - std_lead_time,
                    ymax = avg_lead_time + std_lead_time),
                width = 0.2, color = "black", size = 0.5) +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", name = "Lead Time") +
  labs(
    title = "Average Lead Time by Region",
    subtitle = "Error bars show ±1 Standard Deviation",
    x = "Region",
    y = "Lead Time (Days)"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10))

print(viz1)
ggsave("viz1_lead_time_by_region.png", viz1, width = 12, height = 7, dpi = 300)


# Lead Time Variability (Coefficient of Variation)

cat("VIZ 2: Lead Time Variability by Region\n")

viz2 <- df_clean %>%
  group_by(order_region) %>%
  summarise(
    mean_lt = mean(lead_time, na.rm = TRUE),
    sd_lt = sd(lead_time, na.rm = TRUE),
    cv = (sd_lt / mean_lt) * 100,
    .groups = 'drop'
  ) %>%
  arrange(desc(cv)) %>%
  ggplot(aes(x = reorder(order_region, -cv), y = cv, fill = cv)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#3498db", high = "#c0392b", name = "CV %") +
  geom_hline(yintercept = mean(df_clean$lead_time, na.rm = TRUE) * 0.3, 
             linetype = "dashed", color = "black", size = 1, alpha = 0.5) +
  labs(
    title = "Lead Time Variability by Region (Coefficient of Variation)",
    subtitle = "Higher CV = More Unpredictable Lead Times",
    x = "Region",
    y = "Coefficient of Variation (%)"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10))

print(viz2)
ggsave("viz2_lead_time_variability.png", viz2, width = 12, height = 7, dpi = 300)


# Late Delivery Risk by Shipping Mode


cat("VIZ 3: Late Delivery Risk by Shipping Mode\n")

viz3 <- df_clean %>%
  group_by(shipping_mode) %>%
  summarise(
    total_orders = n(),
    late_deliveries = sum(late_delivery_risk, na.rm = TRUE),
    risk_percentage = (late_deliveries / total_orders) * 100,
    .groups = 'drop'
  ) %>%
  arrange(desc(risk_percentage)) %>%
  ggplot(aes(x = reorder(shipping_mode, -risk_percentage), 
             y = risk_percentage, fill = shipping_mode)) +
  geom_col(alpha = 0.8) +
  geom_text(aes(label = paste0(round(risk_percentage, 1), "%")), 
            vjust = -0.5, size = 4, fontface = "bold") +
  scale_fill_brewer(palette = "Set2") +
  labs(
    title = "Late Delivery Risk by Shipping Mode",
    x = "Shipping Mode",
    y = "Risk Percentage (%)",
    fill = "Shipping Mode"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        legend.position = "none")

print(viz3)
ggsave("viz3_late_delivery_risk_shipping.png", viz3, width = 12, height = 7, dpi = 300)


# Lead Time Distribution by Shipping Mode (Box Plot)


cat("VIZ 4: Lead Time Distribution by Shipping Mode (Box Plot)\n")

viz4 <- ggplot(df_clean, aes(x = reorder(shipping_mode, lead_time, FUN = median), 
                             y = lead_time, fill = shipping_mode)) +
  geom_boxplot(alpha = 0.7, outlier.color = "red", outlier.size = 2) +
  scale_fill_brewer(palette = "Pastel1") +
  labs(
    title = "Lead Time Distribution by Shipping Mode",
    x = "Shipping Mode",
    y = "Lead Time (Days)",
    fill = "Shipping Mode"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        legend.position = "none")

print(viz4)
ggsave("viz4_lead_time_distribution_boxplot.png", viz4, width = 12, height = 7, dpi = 300)


# Regional Performance Matrix (Scatter)


cat("VIZ 5: Regional Performance Matrix\n")

regional_metrics <- df_clean %>%
  group_by(order_region) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    late_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    order_count = n(),
    .groups = 'drop'
  )

viz5 <- regional_metrics %>%
  ggplot(aes(x = avg_lead_time, y = late_risk, size = order_count)) +
  geom_point(aes(color = order_region), alpha = 0.6) +
  geom_text(aes(label = order_region), size = 3, hjust = 0.5, vjust = -1) +
  scale_size_continuous(name = "Order Count", range = c(5, 15)) +
  labs(
    title = "Regional Performance Matrix",
    subtitle = "X-axis: Lead Time | Y-axis: Risk | Size: Order Volume",
    x = "Average Lead Time (Days)",
    y = "Late Delivery Risk (%)",
    color = "Region"
  ) +
  theme(legend.position = "right", axis.text = element_text(size = 10))

print(viz5)
ggsave("viz5_regional_performance_matrix.png", viz5, width = 13, height = 8, dpi = 300)


# Product Category Impact on Lead Time

cat("VIZ 6: Lead Time by Product Category\n")

viz6 <- df_clean %>%
  group_by(category_name) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    late_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    count = n(),
    .groups = 'drop'
  ) %>%
  arrange(desc(avg_lead_time)) %>%
  head(15) %>%  # Top 15 categories
  ggplot(aes(x = reorder(category_name, avg_lead_time),
             y = avg_lead_time, fill = late_risk)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", 
                      name = "Risk %") +
  coord_flip() +
  labs(
    title = "Lead Time by Product Category (Top 15)",
    subtitle = "Color intensity indicates stock-out risk",
    x = "Product Category",
    y = "Average Lead Time (Days)"
  )

print(viz6)
ggsave("viz6_lead_time_by_category.png", viz6, width = 12, height = 8, dpi = 300)

# Delivery Status Distribution (Pie Chart)

cat("VIZ 7: Delivery Status Distribution\n")

viz7 <- df_clean %>%
  group_by(delivery_status) %>%
  summarise(count = n(), .groups = 'drop') %>%
  mutate(percentage = (count / sum(count)) * 100) %>%
  ggplot(aes(x = "", y = count, fill = delivery_status)) +
  geom_bar(stat = "identity", width = 1, alpha = 0.8) +
  coord_polar("y", start = 0) +
  geom_text(aes(label = paste0(round(percentage, 1), "%")), 
            position = position_stack(vjust = 0.5), 
            fontface = "bold", size = 4) +
  scale_fill_brewer(palette = "Set3") +
  labs(
    title = "Delivery Status Distribution",
    fill = "Status"
  ) +
  theme(axis.text = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        legend.text = element_text(size = 10))

print(viz7)
ggsave("viz7_delivery_status_pie.png", viz7, width = 10, height = 8, dpi = 300)


#Time Series - Lead Time Trend Over Time


cat("VIZ 8: Lead Time Trend Over Time\n")

viz8 <- df_clean %>%
  mutate(year_month = format(order_date_dateorders_, "%Y-%m")) %>%
  group_by(year_month) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  ggplot(aes(x = year_month, y = avg_lead_time, group = 1)) +
  geom_line(color = "#3498db", size = 1) +
  geom_point(color = "#e74c3c", size = 3, alpha = 0.7) +
  geom_smooth(method = "loess", se = TRUE, alpha = 0.2, 
              color = "#2ecc71", fill = "#d5f4e6") +
  labs(
    title = "Lead Time Trend Over Time",
    x = "Month-Year",
    y = "Average Lead Time (Days)",
    subtitle = "Blue line = Actual trend, Green area = Smoothed trend"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 9))

print(viz8)
ggsave("viz8_lead_time_trend.png", viz8, width = 13, height = 7, dpi = 300)


# Late Delivery Risk by Region


cat("VIZ 9: Late Delivery Risk by Region\n")

viz9 <- df_clean %>%
  group_by(order_region) %>%
  summarise(
    late_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    total_orders = n(),
    .groups = 'drop'
  ) %>%
  arrange(desc(late_risk)) %>%
  ggplot(aes(x = reorder(order_region, -late_risk), 
             y = late_risk, fill = late_risk)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", name = "Risk %") +
  geom_text(aes(label = paste0(round(late_risk, 1), "%")), 
            vjust = -0.5, fontface = "bold", size = 3.5) +
  labs(
    title = "Late Delivery Risk by Region",
    x = "Region",
    y = "Late Delivery Risk (%)"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        legend.position = "none")

print(viz9)
ggsave("viz9_late_delivery_risk_region.png", viz9, width = 12, height = 7, dpi = 300)


# Order Quantity vs Lead Time

cat("VIZ 10: Order Quantity vs Lead Time\n")

viz10 <- df_clean %>%
  sample_n(min(5000, nrow(df_clean))) %>%  # Sample for clarity
  ggplot(aes(x = order_item_quantity, y = lead_time, 
             color = as.factor(late_delivery_risk), size = as.factor(late_delivery_risk))) +
  geom_point(alpha = 0.5) +
  scale_color_manual(values = c("0" = "#2ecc71", "1" = "#e74c3c"),
                     labels = c("0" = "On-time", "1" = "Late"),
                     name = "Delivery Status") +
  scale_size_manual(values = c("0" = 2, "1" = 3),
                    labels = c("0" = "On-time", "1" = "Late"),
                    guide = "none") +
  labs(
    title = "Order Quantity vs Lead Time",
    x = "Order Quantity (Units)",
    y = "Lead Time (Days)",
    subtitle = "Sample of 5000 orders for clarity"
  ) +
  facet_wrap(~shipping_mode) +
  theme(axis.text = element_text(size = 9))

print(viz10)
ggsave("viz10_quantity_vs_leadtime.png", viz10, width = 14, height = 8, dpi = 300)


# Shipping Mode Comparison - Lead Time vs Cost

cat("VIZ 11: Shipping Mode Analysis\n")

shipping_analysis <- df_clean %>%
  group_by(shipping_mode) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    late_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    avg_profit = mean(order_profit_per_order, na.rm = TRUE),
    total_orders = n(),
    .groups = 'drop'
  )

viz11 <- shipping_analysis %>%
  ggplot(aes(x = avg_lead_time, y = late_risk, 
             size = total_orders, color = shipping_mode)) +
  geom_point(alpha = 0.7) +
  geom_label(aes(label = shipping_mode), size = 3.5, 
             position = position_jitter(width = 0.1, height = 0.1)) +
  labs(
    title = "Shipping Mode Comparison",
    x = "Average Lead Time (Days)",
    y = "Late Delivery Risk (%)",
    size = "Order Volume",
    subtitle = "Optimal shipping: Low lead time + Low risk + High volume"
  ) +
  theme(legend.position = "none", axis.text = element_text(size = 10))

print(viz11)
ggsave("viz11_shipping_mode_comparison.png", viz11, width = 12, height = 7, dpi = 300)


# Order Status Distribution
cat("VIZ 12: Order Status Distribution\n")

viz12 <- df_clean %>%
  group_by(order_status) %>%
  summarise(count = n(), .groups = 'drop') %>%
  mutate(percentage = (count / sum(count)) * 100) %>%
  arrange(desc(percentage)) %>%
  head(10) %>%
  ggplot(aes(x = reorder(order_status, -count), y = count, fill = order_status)) +
  geom_col(alpha = 0.8) +
  geom_text(aes(label = paste0(round(percentage, 1), "%")), 
            vjust = -0.5, fontface = "bold", size = 3.5) +
  scale_fill_brewer(palette = "Set2") +
  labs(
    title = "Order Status Distribution (Top 10)",
    x = "Order Status",
    y = "Number of Orders"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        legend.position = "none")

print(viz12)
ggsave("viz12_order_status_distribution.png", viz12, width = 12, height = 7, dpi = 300)

# Lead Time vs Profit by Region

cat("VIZ 13: Lead Time vs Profit Relationship\n")

viz13 <- df_clean %>%
  group_by(order_region) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    avg_profit = mean(order_profit_per_order, na.rm = TRUE),
    count = n(),
    .groups = 'drop'
  ) %>%
  ggplot(aes(x = avg_lead_time, y = avg_profit, 
             size = count, color = order_region)) +
  geom_point(alpha = 0.6) +
  geom_text(aes(label = order_region), size = 2.5, hjust = 0.5, vjust = -0.8) +
  scale_size_continuous(name = "Orders") +
  labs(
    title = "Lead Time vs Profit by Region",
    x = "Average Lead Time (Days)",
    y = "Average Profit per Order ($)",
    color = "Region"
  ) +
  theme(legend.position = "bottom")

print(viz13)
ggsave("viz13_leadtime_vs_profit.png", viz13, width = 12, height = 7, dpi = 300)


# Heatmap - Lead Time by Region and Shipping Mode

cat("VIZ 14: Heatmap - Lead Time by Region and Shipping Mode\n")

heatmap_data <- df_clean %>%
  group_by(order_region, shipping_mode) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    .groups = 'drop'
  )

viz14 <- ggplot(heatmap_data, aes(x = shipping_mode, y = order_region, 
                                  fill = avg_lead_time)) +
  geom_tile(alpha = 0.8) +
  geom_text(aes(label = round(avg_lead_time, 1)), 
            size = 3.5, fontface = "bold") +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", 
                      name = "Lead Time") +
  labs(
    title = "Heatmap: Average Lead Time (Region × Shipping Mode)",
    x = "Shipping Mode",
    y = "Region"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        axis.text.y = element_text(size = 9))

print(viz14)
ggsave("viz14_heatmap_region_shipping.png", viz14, width = 12, height = 8, dpi = 300)


# Customer Segment Analysis

cat("VIZ 15: Customer Segment Analysis\n")

viz15 <- df_clean %>%
  group_by(customer_segment) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    late_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    avg_profit = mean(order_profit_per_order, na.rm = TRUE),
    total_orders = n(),
    .groups = 'drop'
  ) %>%
  ggplot(aes(x = reorder(customer_segment, -avg_lead_time), 
             y = avg_lead_time, fill = late_risk)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", 
                      name = "Risk %") +
  geom_text(aes(label = paste0(round(late_risk, 1), "%")), 
            vjust = -0.5, fontface = "bold", size = 3.5) +
  labs(
    title = "Lead Time and Risk by Customer Segment",
    x = "Customer Segment",
    y = "Average Lead Time (Days)"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10))

print(viz15)
ggsave("viz15_customer_segment_analysis.png", viz15, width = 12, height = 7, dpi = 300)




