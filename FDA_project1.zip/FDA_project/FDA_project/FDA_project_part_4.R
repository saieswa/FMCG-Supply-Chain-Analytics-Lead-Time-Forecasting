library(tidyverse)
library(ggplot2)
library(scales)
library(gridExtra)
library(zoo)

# Load cleaned data
df_clean <- readRDS("supply_chain_cleaned.rds")

cat("✓ Data loaded successfully\n")
cat("  Total rows:", nrow(df_clean), "\n\n")
cat("\n=== TIME SERIES ANALYSIS: LEAD TIME FORECASTING ===\n")

# Prepare time series data by region
ts_data <- df_clean %>%
  mutate(year_month = format(order_date_dateorders_, "%Y-%m")) %>%
  group_by(year_month, order_region) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    sd_lead_time = sd(lead_time, na.rm = TRUE),
    orders_count = n(),
    stock_out_rate = mean(late_delivery_risk, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  arrange(year_month)

cat("Time series data prepared\n")
cat("  Total time periods:", length(unique(ts_data$year_month)), "\n")
cat("  Regions analyzed:", length(unique(ts_data$order_region)), "\n\n")

# Simple Moving Average (SMA) & Exponential Moving Average (EMA)
regional_forecast <- ts_data %>%
  group_by(order_region) %>%
  arrange(year_month) %>%
  mutate(
    sma_3m = rollmean(avg_lead_time, k = 3, fill = NA, align = "right"),
    sma_6m = rollmean(avg_lead_time, k = 6, fill = NA, align = "right")
  ) %>%
  ungroup()

cat("\n=== LEAD TIME FORECAST BY REGION (Last 12 months) ===\n")
print(tail(regional_forecast, 24))

# ============================================================================
# VISUALIZATION 23: Lead Time Forecast with Moving Averages
# ============================================================================

cat("\nVIZ 23: Lead Time Forecasting by Region...\n")

# Select top regions for clarity
top_regions <- df_clean %>%
  count(order_region, sort = TRUE) %>%
  head(5) %>%
  pull(order_region)

plot23 <- regional_forecast %>%
  filter(order_region %in% top_regions, !is.na(sma_3m)) %>%
  ggplot(aes(x = year_month)) +
  geom_line(aes(y = avg_lead_time, group = order_region, 
                color = order_region), linetype = "dotted", size = 0.5) +
  geom_line(aes(y = sma_3m, group = order_region, 
                color = order_region), size = 1.2) +
  geom_point(aes(y = avg_lead_time, color = order_region), 
             size = 2, alpha = 0.6) +
  labs(
    title = "Lead Time Forecasting by Region (3-Month Moving Average)",
    x = "Month",
    y = "Lead Time (Days)",
    color = "Region",
    subtitle = "Dotted lines = actual values | Solid lines = 3-month SMA (Top 5 regions)"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 9),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    legend.position = "bottom"
  )

print(plot23)
ggsave("viz23_lead_time_forecast.png", plot23, width = 13, height = 7, dpi = 300)

# ============================================================================
# VISUALIZATION 24: Multi-Region Forecast Comparison
# ============================================================================

cat("\nVIZ 24: Multi-Region Forecast Comparison...\n")

plot24 <- regional_forecast %>%
  filter(order_region %in% top_regions) %>%
  ggplot(aes(x = year_month, group = order_region)) +
  geom_line(aes(y = avg_lead_time), color = "#3498db", size = 0.8) +
  geom_line(aes(y = sma_3m), color = "#e74c3c", size = 1.2) +
  facet_wrap(~order_region, scales = "free_y", ncol = 2) +
  labs(
    title = "Regional Lead Time Trends with 3-Month SMA",
    x = "Month",
    y = "Lead Time (Days)",
    subtitle = "Blue = Actual | Red = 3-month moving average"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    strip.text = element_text(size = 10, face = "bold")
  )

print(plot24)
ggsave("viz24_regional_forecast_comparison.png", plot24, width = 13, height = 10, dpi = 300)

# ============================================================================
# STEP 2: ANOMALY DETECTION IN LEAD TIMES
# ============================================================================

cat("\n=== ANOMALY DETECTION: IDENTIFYING OUTLIERS ===\n")

# Calculate z-scores for lead time anomalies
anomaly_detection <- df_clean %>%
  group_by(order_region, category_name) %>%
  mutate(
    mean_lt = mean(lead_time, na.rm = TRUE),
    sd_lt = sd(lead_time, na.rm = TRUE),
    z_score = (lead_time - mean_lt) / sd_lt,
    is_anomaly = abs(z_score) > 2.5,  # Threshold for anomaly
  ) %>%
  ungroup() %>%
  filter(is_anomaly == TRUE) %>%
  arrange(desc(abs(z_score)))

cat("\nAnomalies detected:", nrow(anomaly_detection), "\n")
cat("Anomaly rate:", round((nrow(anomaly_detection) / nrow(df_clean)) * 100, 2), "%\n\n")

cat("\n=== TOP 10 LEAD TIME ANOMALIES ===\n")
print(head(anomaly_detection %>% 
             select(order_region, category_name, lead_time, 
                    z_score, late_delivery_risk), 10))

# ============================================================================
# VISUALIZATION 25: Anomaly Detection Scatter Plot


cat("\nVIZ 25: Anomaly Detection by Region...\n")

plot25 <- df_clean %>%
  filter(order_region %in% top_regions) %>%
  group_by(order_region, category_name) %>%
  mutate(
    mean_lt = mean(lead_time, na.rm = TRUE),
    sd_lt = sd(lead_time, na.rm = TRUE),
    z_score = (lead_time - mean_lt) / sd_lt,
    is_anomaly = abs(z_score) > 2.5
  ) %>%
  ungroup() %>%
  sample_n(min(5000, nrow(.))) %>%  # Sample for performance
  ggplot(aes(x = lead_time, y = late_delivery_risk * 100, 
             color = is_anomaly, size = is_anomaly)) +
  geom_point(alpha = 0.5) +
  scale_color_manual(values = c("FALSE" = "#3498db", "TRUE" = "#e74c3c"),
                     name = "Status",
                     labels = c("FALSE" = "Normal", "TRUE" = "Anomaly")) +
  scale_size_manual(values = c("FALSE" = 2, "TRUE" = 4),
                    guide = "none") +
  facet_wrap(~order_region, scales = "free") +
  labs(
    title = "Lead Time Anomaly Detection by Region",
    x = "Lead Time (Days)",
    y = "Late Delivery Risk (%)",
    subtitle = "Red points = Potential anomalies (|z-score| > 2.5)"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 8),
    axis.text.y = element_text(size = 8),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    strip.text = element_text(face = "bold", size = 9)
  )

print(plot25)
ggsave("viz25_anomaly_detection.png", plot25, width = 13, height = 9, dpi = 300)


# STEP 3: BINARY CLASSIFICATION - STOCK-OUT RISK PREDICTION

cat("\n=== LOGISTIC REGRESSION: PREDICTING STOCK-OUT RISK ===\n")

# Prepare data for modeling
model_data <- df_clean %>%
  select(
    lead_time,
    order_item_quantity,
    late_delivery_risk,
    order_item_total,
    order_item_profit_ratio,
    order_profit_per_order,
    order_region,
    category_name,
    shipping_mode
  ) %>%
  na.omit()

cat("Model data prepared\n")
cat("  Total observations:", nrow(model_data), "\n")
cat("  Features:", ncol(model_data) - 1, "\n\n")

# Create dummy variables for categorical features
model_data <- model_data %>%
  mutate(
    region_encoded = as.numeric(factor(order_region)),
    category_encoded = as.numeric(factor(category_name)),
    shipping_encoded = as.numeric(factor(shipping_mode))
  )

# Split data: 80% training, 20% testing
set.seed(123)
train_idx <- sample(1:nrow(model_data), size = 0.8 * nrow(model_data))
train_data <- model_data[train_idx, ]
test_data <- model_data[-train_idx, ]

cat("Data split completed\n")
cat("  Training set:", nrow(train_data), "observations\n")
cat("  Test set:", nrow(test_data), "observations\n\n")

# Build logistic regression model
cat("Training logistic regression model...\n")

logreg_model <- glm(
  late_delivery_risk ~ lead_time + order_item_quantity + order_item_total + 
    order_item_profit_ratio + region_encoded + 
    category_encoded + shipping_encoded,
  family = "binomial",
  data = train_data
)

cat("\n=== MODEL SUMMARY ===\n")
print(summary(logreg_model))

# Model predictions
train_pred <- predict(logreg_model, train_data, type = "response")
test_pred <- predict(logreg_model, test_data, type = "response")

# Classification metrics
train_class <- ifelse(train_pred > 0.5, 1, 0)
test_class <- ifelse(test_pred > 0.5, 1, 0)

train_accuracy <- mean(train_class == train_data$late_delivery_risk)
test_accuracy <- mean(test_class == test_data$late_delivery_risk)

# Confusion Matrix for test set
conf_matrix <- table(Predicted = test_class, Actual = test_data$late_delivery_risk)

# Calculate additional metrics
true_positives <- conf_matrix[2, 2]
false_positives <- conf_matrix[2, 1]
true_negatives <- conf_matrix[1, 1]
false_negatives <- conf_matrix[1, 2]

precision <- true_positives / (true_positives + false_positives)
recall <- true_positives / (true_positives + false_negatives)
f1_score <- 2 * (precision * recall) / (precision + recall)

cat("\n=== MODEL PERFORMANCE ===\n")
cat("Training Accuracy:", round(train_accuracy * 100, 2), "%\n")
cat("Testing Accuracy:", round(test_accuracy * 100, 2), "%\n")
cat("Precision:", round(precision * 100, 2), "%\n")
cat("Recall (Sensitivity):", round(recall * 100, 2), "%\n")
cat("F1-Score:", round(f1_score, 3), "\n\n")

cat("CONFUSION MATRIX (Test Set):\n")
print(conf_matrix)


# Model Predictions vs Actual Values


cat("\nVIZ 26: Model Predictions Visualization...\n")

prediction_comparison <- data.frame(
  actual = test_data$late_delivery_risk,
  predicted = test_pred,
  lead_time = test_data$lead_time,
  region = test_data$order_region
) %>%
  filter(region %in% top_regions)  # Focus on top regions

plot26 <- prediction_comparison %>%
  ggplot(aes(x = lead_time, y = predicted, color = as.factor(actual))) +
  geom_point(alpha = 0.5, size = 2) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "red", size = 1) +
  scale_color_manual(
    values = c("0" = "#2ecc71", "1" = "#e74c3c"),
    name = "Actual Risk",
    labels = c("0" = "No Risk", "1" = "Risk")
  ) +
  labs(
    title = "Stock-out Risk Prediction Model",
    x = "Lead Time (Days)",
    y = "Predicted Risk Probability",
    subtitle = sprintf("Model Accuracy: %.2f%% | Red line = Decision threshold (0.5)",
                       test_accuracy * 100)
  ) +
  facet_wrap(~region) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 9),
    axis.text.y = element_text(size = 9),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    strip.text = element_text(face = "bold")
  )

print(plot26)
ggsave("viz26_prediction_model.png", plot26, width = 13, height = 8, dpi = 300)


# VISUALIZATION 27: Feature Importance (Coefficients)
cat("\nVIZ 27: Feature Importance Analysis...\n")

feature_importance <- data.frame(
  feature = names(coef(logreg_model))[-1],
  coefficient = coef(logreg_model)[-1],
  odds_ratio = exp(coef(logreg_model))[-1]
) %>%
  arrange(desc(abs(coefficient)))

plot27 <- feature_importance %>%
  ggplot(aes(x = reorder(feature, coefficient), 
             y = coefficient, fill = coefficient > 0)) +
  geom_col(alpha = 0.8) +
  scale_fill_manual(
    values = c("TRUE" = "#e74c3c", "FALSE" = "#2ecc71"),
    labels = c("TRUE" = "Increases Risk", "FALSE" = "Decreases Risk"),
    name = "Effect"
  ) +
  coord_flip() +
  labs(
    title = "Feature Importance in Risk Prediction",
    x = "Features",
    y = "Logistic Regression Coefficient",
    subtitle = "Positive = increases stock-out risk | Negative = decreases risk"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    axis.text = element_text(size = 10)
  )

print(plot27)
ggsave("viz27_feature_importance.png", plot27, width = 11, height = 7, dpi = 300)


# ROC-like Performance Curve


cat("\nVIZ 28: Model Performance at Different Thresholds...\n")

# Sort predictions and calculate metrics at different thresholds
thresholds <- seq(0, 1, by = 0.05)
performance_metrics <- data.frame()

for (threshold in thresholds) {
  pred_class <- ifelse(test_pred > threshold, 1, 0)
  tp <- sum(pred_class == 1 & test_data$late_delivery_risk == 1)
  fp <- sum(pred_class == 1 & test_data$late_delivery_risk == 0)
  tn <- sum(pred_class == 0 & test_data$late_delivery_risk == 0)
  fn <- sum(pred_class == 0 & test_data$late_delivery_risk == 1)
  
  sensitivity <- ifelse((tp + fn) > 0, tp / (tp + fn), 0)
  specificity <- ifelse((tn + fp) > 0, tn / (tn + fp), 0)
  accuracy <- (tp + tn) / length(test_data$late_delivery_risk)
  
  performance_metrics <- rbind(performance_metrics, data.frame(
    threshold = threshold,
    sensitivity = sensitivity,
    specificity = specificity,
    accuracy = accuracy
  ))
}

plot28 <- performance_metrics %>%
  pivot_longer(cols = c(sensitivity, specificity, accuracy),
               names_to = "metric", values_to = "value") %>%
  ggplot(aes(x = threshold, y = value, color = metric, size = metric)) +
  geom_line() +
  geom_point() +
  scale_size_manual(
    values = c("sensitivity" = 1.2, "specificity" = 1.2, "accuracy" = 1.5),
    guide = "none"
  ) +
  scale_color_manual(
    values = c("sensitivity" = "#3498db", "specificity" = "#e74c3c", 
               "accuracy" = "#2ecc71"),
    labels = c("sensitivity" = "Sensitivity (True Positive Rate)",
               "specificity" = "Specificity (True Negative Rate)",
               "accuracy" = "Overall Accuracy"),
    name = "Metric"
  ) +
  labs(
    title = "Model Performance at Different Classification Thresholds",
    x = "Classification Threshold",
    y = "Metric Value",
    subtitle = "Optimal threshold balances sensitivity and specificity"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    legend.position = "bottom"
  )

print(plot28)
ggsave("viz28_performance_curve.png", plot28, width = 12, height = 7, dpi = 300)


# VISUALIZATION 29: Prediction Distribution by Risk Category

cat("\nVIZ 29: Prediction Distribution Analysis...\n")

prediction_dist <- data.frame(
  predicted_prob = test_pred,
  actual_risk = as.factor(test_data$late_delivery_risk)
)

plot29 <- prediction_dist %>%
  ggplot(aes(x = predicted_prob, fill = actual_risk)) +
  geom_histogram(alpha = 0.6, bins = 50, position = "identity") +
  geom_vline(xintercept = 0.5, linetype = "dashed", 
             color = "red", size = 1.2) +
  scale_fill_manual(
    values = c("0" = "#2ecc71", "1" = "#e74c3c"),
    labels = c("0" = "No Late Delivery", "1" = "Late Delivery"),
    name = "Actual Status"
  ) +
  labs(
    title = "Distribution of Predicted Probabilities",
    subtitle = "Separation between classes indicates model discrimination ability",
    x = "Predicted Probability of Late Delivery",
    y = "Frequency"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    legend.position = "bottom"
  )

print(plot29)
ggsave("viz29_prediction_distribution.png", plot29, width = 12, height = 7, dpi = 300)


# SAVE ALL RESULTS
cat("\n=== SAVING RESULTS ===\n")

# Save model
saveRDS(logreg_model, "stockout_risk_model.rds")
cat("✓ Model saved to: stockout_risk_model.rds\n")

# Save feature importance
write.csv(feature_importance, "feature_importance.csv", row.names = FALSE)
cat("✓ Feature importance saved to: feature_importance.csv\n")

# Save time series forecasts
write.csv(regional_forecast, "regional_lead_time_forecast.csv", row.names = FALSE)
cat("✓ Time series forecast saved to: regional_lead_time_forecast.csv\n")

# Save anomaly detection results
write.csv(anomaly_detection, "lead_time_anomalies.csv", row.names = FALSE)
cat("✓ Anomaly detection results saved to: lead_time_anomalies.csv\n")

# Save model performance metrics
model_performance <- data.frame(
  Metric = c("Training Accuracy", "Testing Accuracy", "Precision", 
             "Recall", "F1-Score", "True Positives", "False Positives",
             "True Negatives", "False Negatives"),
  Value = c(
    round(train_accuracy * 100, 2),
    round(test_accuracy * 100, 2),
    round(precision * 100, 2),
    round(recall * 100, 2),
    round(f1_score, 3),
    true_positives,
    false_positives,
    true_negatives,
    false_negatives
  )
)

write.csv(model_performance, "model_performance_metrics.csv", row.names = FALSE)
cat("✓ Model performance metrics saved to: model_performance_metrics.csv\n")

# Save threshold analysis
write.csv(performance_metrics, "threshold_performance_analysis.csv", row.names = FALSE)
cat("✓ Threshold analysis saved to: threshold_performance_analysis.csv\n")
cat(" MODEL PERFORMANCE SUMMARY:\n")
cat("  • Training Accuracy:", round(train_accuracy * 100, 2), "%\n")
cat("  • Testing Accuracy:", round(test_accuracy * 100, 2), "%\n")
cat("  • Precision:", round(precision * 100, 2), "%\n")
cat("  • Recall:", round(recall * 100, 2), "%\n")
cat("  • F1-Score:", round(f1_score, 3), "\n\n")

cat("KEY FINDINGS:\n")
cat("  • Total anomalies detected:", nrow(anomaly_detection), "\n")
cat("  • Anomaly rate:", round((nrow(anomaly_detection) / nrow(df_clean)) * 100, 2), "%\n")
cat("  • Time periods analyzed:", length(unique(ts_data$year_month)), "\n")
cat("  • Regions forecasted:", length(unique(ts_data$order_region)), "\n\n")