# ============================================================================
# FMCG Supply Chain Analytics - ADVANCED PREDICTIVE MODELING
# Using Gaussian Process Regression (GPR) for Uncertainty-Aware Forecasting
# FIXED VERSION - Handles NA values properly
# ============================================================================

# Install required packages (run once)
# install.packages(c("kernlab", "tidyverse", "ggplot2", "caret", "scales"))

library(kernlab)      # For Gaussian Process Regression
library(tidyverse)
library(ggplot2)
library(caret)
library(scales)

cat("ADVANCED PREDICTIVE MODELING: GAUSSIAN PROCESS REGRESSION\n")


# Load cleaned data
df_clean <- readRDS("supply_chain_cleaned.rds")

cat("✓ Data loaded successfully\n")
cat("  Total records:", nrow(df_clean), "\n\n")

# ============================================================================
# STEP 1: PREPARE DATA FOR GPR (WITH THOROUGH CLEANING)
# ============================================================================

cat("STEP 1: DATA PREPARATION FOR GPR\n")
cat("-", rep("-", 76), "\n\n")

# Select relevant features and remove NA immediately
model_data <- df_clean %>%
  select(
    lead_time,
    order_item_quantity,
    late_delivery_risk,
    order_item_total,
    order_profit_per_order,
    order_region,
    category_name,
    shipping_mode,
    days_for_shipping_real_,
    days_for_shipment_scheduled_
  ) %>%
  # Remove any rows with NA in ANY column
  drop_na() %>%
  # Remove infinite values
  filter(
    is.finite(lead_time),
    is.finite(order_item_quantity),
    is.finite(late_delivery_risk),
    is.finite(order_item_total),
    is.finite(order_profit_per_order),
    is.finite(days_for_shipping_real_),
    is.finite(days_for_shipment_scheduled_)
  )

cat("Records after thorough cleaning:", nrow(model_data), "\n")

# Check for remaining NAs
na_check <- colSums(is.na(model_data))
cat("\nNA values per column:\n")
print(na_check)

if(sum(na_check) > 0) {
  stop("ERROR: Still have NA values. Please check data.")
}

# Encode categorical variables as numeric
model_data <- model_data %>%
  mutate(
    region_encoded = as.numeric(factor(order_region)),
    category_encoded = as.numeric(factor(category_name)),
    shipping_encoded = as.numeric(factor(shipping_mode))
  )

# Create feature matrix
features <- model_data %>%
  select(
    days_for_shipping_real_,
    days_for_shipment_scheduled_,
    order_item_quantity,
    order_item_total,
    order_profit_per_order,
    region_encoded,
    category_encoded,
    shipping_encoded
  )

# Target variable (late delivery risk) - must be numeric and no NAs
target <- as.numeric(model_data$late_delivery_risk)

# Final check for NAs
if(any(is.na(target))) {
  cat("WARNING: Found", sum(is.na(target)), "NA values in target. Removing...\n")
  valid_indices <- !is.na(target)
  features <- features[valid_indices, ]
  target <- target[valid_indices]
}

cat("\nFinal check:\n")
cat("  Features shape:", nrow(features), "x", ncol(features), "\n")
cat("  Target length:", length(target), "\n")
cat("  NAs in features:", sum(is.na(features)), "\n")
cat("  NAs in target:", sum(is.na(target)), "\n")

# Scale features for better GPR performance
features_scaled <- as.data.frame(scale(features))

# Check for NAs introduced by scaling
if(any(is.na(features_scaled))) {
  cat("WARNING: Scaling introduced NAs. Removing affected columns...\n")
  features_scaled <- features_scaled[, colSums(is.na(features_scaled)) == 0]
}

# Add target back
features_scaled$target <- target

cat("\nFeature scaling complete\n")
cat("Features used:", ncol(features), "\n")
print(colnames(features))

# ============================================================================
# STEP 2: TRAIN-TEST SPLIT
# ============================================================================

cat("\n\nSTEP 2: TRAIN-TEST SPLIT\n")
cat("-", rep("-", 76), "\n\n")

set.seed(123)

# Sample data for GPR (GPR is computationally expensive)
# Use smaller sample to avoid memory issues
sample_size <- min(3000, nrow(features_scaled))
sample_indices <- sample(1:nrow(features_scaled), sample_size)
sampled_data <- features_scaled[sample_indices, ]

cat("Sampled data size:", nrow(sampled_data), "\n")

# Split into train (80%) and test (20%)
train_size <- floor(0.8 * nrow(sampled_data))
train_indices <- sample(1:nrow(sampled_data), train_size)

train_data <- sampled_data[train_indices, ]
test_data <- sampled_data[-train_indices, ]

cat("Training set size:", nrow(train_data), "\n")
cat("Testing set size:", nrow(test_data), "\n\n")

# Prepare matrices
train_x <- as.matrix(train_data[, -ncol(train_data)])
train_y <- as.factor(train_data$target)  # Convert to factor for classification

test_x <- as.matrix(test_data[, -ncol(test_data)])
test_y <- as.factor(test_data$target)

# Final validation
cat("Final data validation:\n")
cat("  Train X: ", nrow(train_x), "x", ncol(train_x), "\n")
cat("  Train Y levels:", levels(train_y), "\n")
cat("  Train Y distribution:", table(train_y), "\n")
cat("  Any NA in train_x:", any(is.na(train_x)), "\n")
cat("  Any NA in train_y:", any(is.na(train_y)), "\n\n")

# ============================================================================
# STEP 3: BUILD GAUSSIAN PROCESS REGRESSION MODEL
# ============================================================================

cat("\nSTEP 3: BUILDING GAUSSIAN PROCESS REGRESSION MODEL\n")
cat("-", rep("-", 76), "\n\n")

cat("Training GPR model (this may take 2-3 minutes)...\n\n")

# Build GPR model with proper settings
tryCatch({
  gpr_model <- gausspr(
    x = train_x,
    y = train_y,
    kernel = "rbfdot",              # Radial Basis Function kernel
    kpar = "automatic",             # Automatic kernel parameter selection
    type = "classification",         # Binary classification
    scaled = FALSE,                  # Already scaled
    cross = 0                        # No cross-validation for speed
  )
  
  cat("✓ GPR model trained successfully\n\n")
  cat("Model Summary:\n")
  print(gpr_model)
  
}, error = function(e) {
  cat("ERROR in GPR training:", e$message, "\n")
  cat("Switching to simplified model...\n")
  
  # Fallback to simpler kernel
  gpr_model <<- gausspr(
    x = train_x,
    y = train_y,
    kernel = "rbfdot",
    kpar = list(sigma = 1),
    type = "classification"
  )
})

# ============================================================================
# STEP 4: MODEL PREDICTIONS WITH UNCERTAINTY
# ============================================================================

cat("\n\nSTEP 4: GENERATING PREDICTIONS WITH UNCERTAINTY ESTIMATES\n")
cat("-", rep("-", 76), "\n\n")

# Make predictions on test set
test_predictions <- predict(gpr_model, test_x, type = "probabilities")

# Get probability for class "1" (late delivery)
if(is.matrix(test_predictions)) {
  test_pred_prob <- test_predictions[, "1"]
} else {
  test_pred_prob <- test_predictions
}

# Convert to binary predictions
test_pred_binary <- ifelse(test_pred_prob > 0.5, "1", "0")

# Calculate accuracy
accuracy <- mean(test_pred_binary == as.character(test_y))
cat("Model Accuracy:", round(accuracy * 100, 2), "%\n\n")

# Confusion Matrix
conf_matrix <- table(Predicted = test_pred_binary, Actual = test_y)
cat("Confusion Matrix:\n")
print(conf_matrix)

# Calculate metrics (safely handle edge cases)
if(all(dim(conf_matrix) == c(2, 2))) {
  tn <- conf_matrix["0", "0"]
  fp <- conf_matrix["0", "1"]
  fn <- conf_matrix["1", "0"]
  tp <- conf_matrix["1", "1"]
  
  precision <- ifelse((tp + fp) > 0, tp / (tp + fp), 0)
  recall <- ifelse((tp + fn) > 0, tp / (tp + fn), 0)
  f1_score <- ifelse((precision + recall) > 0, 
                     2 * (precision * recall) / (precision + recall), 0)
} else {
  precision <- recall <- f1_score <- NA
}

cat("\nPerformance Metrics:\n")
cat("  Accuracy:", round(accuracy * 100, 2), "%\n")
cat("  Precision:", round(precision * 100, 2), "%\n")
cat("  Recall:", round(recall * 100, 2), "%\n")
cat("  F1-Score:", round(f1_score * 100, 2), "%\n")

# ============================================================================
# STEP 5: UNCERTAINTY QUANTIFICATION (NOVELTY!)
# ============================================================================

cat("\n\nSTEP 5: UNCERTAINTY QUANTIFICATION\n")
cat("-", rep("-", 76), "\n\n")

cat("Computing prediction uncertainty...\n\n")

# Store original indices for matching
original_indices <- sample_indices[-train_indices]

# Create prediction dataframe with uncertainty
predictions_df <- data.frame(
  actual = as.numeric(as.character(test_y)),
  predicted_prob = as.numeric(test_pred_prob),
  predicted_class = as.numeric(test_pred_binary),
  lead_time = model_data$lead_time[original_indices],
  region = model_data$order_region[original_indices],
  shipping_mode = model_data$shipping_mode[original_indices]
)

# Calculate confidence (distance from decision boundary)
predictions_df$confidence <- abs(predictions_df$predicted_prob - 0.5) * 2

# Categorize by uncertainty
predictions_df$uncertainty_level <- cut(
  predictions_df$confidence,
  breaks = c(0, 0.33, 0.67, 1.0),
  labels = c("High Uncertainty", "Medium Uncertainty", "High Confidence"),
  include.lowest = TRUE
)

cat("Uncertainty Distribution:\n")
print(table(predictions_df$uncertainty_level))

# ============================================================================
# VISUALIZATION 1: Prediction Probability Distribution
# ============================================================================

cat("\n\nGenerating visualizations...\n\n")

viz1 <- ggplot(predictions_df, aes(x = predicted_prob, fill = as.factor(actual))) +
  geom_histogram(bins = 30, alpha = 0.7, position = "identity") +
  geom_vline(xintercept = 0.5, linetype = "dashed", color = "red", size = 1) +
  scale_fill_manual(
    values = c("0" = "#2ecc71", "1" = "#e74c3c"),
    labels = c("0" = "On-time", "1" = "Late"),
    name = "Actual Status"
  ) +
  labs(
    title = "Gaussian Process Regression: Prediction Probability Distribution",
    subtitle = "GPR provides probabilistic predictions with uncertainty estimates",
    x = "Predicted Probability of Late Delivery",
    y = "Count"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5, size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 11)
  )

print(viz1)
ggsave("gpr_viz1_probability_distribution.png", viz1, width = 12, height = 7, dpi = 300)

# ============================================================================
# VISUALIZATION 2: Uncertainty Analysis
# ============================================================================

viz2 <- ggplot(predictions_df, aes(x = uncertainty_level, fill = uncertainty_level)) +
  geom_bar(alpha = 0.8) +
  geom_text(stat = "count", aes(label = after_stat(count)), 
            vjust = -0.5, fontface = "bold", size = 4) +
  scale_fill_manual(
    values = c("High Uncertainty" = "#e74c3c", 
               "Medium Uncertainty" = "#f39c12", 
               "High Confidence" = "#2ecc71")
  ) +
  labs(
    title = "GPR Uncertainty Levels in Predictions",
    subtitle = "Novel feature: Quantifying prediction confidence",
    x = "Uncertainty Level",
    y = "Number of Predictions"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5, size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 11),
    legend.position = "none"
  )

print(viz2)
ggsave("gpr_viz2_uncertainty_levels.png", viz2, width = 12, height = 7, dpi = 300)

# ============================================================================
# VISUALIZATION 3: Lead Time vs Prediction Confidence
# ============================================================================

viz3 <- ggplot(predictions_df, aes(x = lead_time, y = confidence, 
                                   color = as.factor(actual))) +
  geom_point(alpha = 0.6, size = 2.5) +
  geom_smooth(method = "loess", se = TRUE, alpha = 0.2) +
  scale_color_manual(
    values = c("0" = "#2ecc71", "1" = "#e74c3c"),
    labels = c("0" = "On-time", "1" = "Late"),
    name = "Actual Status"
  ) +
  labs(
    title = "GPR: Lead Time vs Prediction Confidence",
    subtitle = "Higher lead time reveals prediction certainty patterns",
    x = "Lead Time (Days)",
    y = "Prediction Confidence (0-1)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5, size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 11)
  )

print(viz3)
ggsave("gpr_viz3_leadtime_confidence.png", viz3, width = 12, height = 7, dpi = 300)

# ============================================================================
# STEP 6: SAVE RESULTS & MODEL
# ============================================================================

cat("\n\nSTEP 6: SAVING RESULTS\n")
cat("-", rep("-", 76), "\n\n")

# Save predictions with uncertainty
write.csv(predictions_df, "gpr_predictions_with_uncertainty.csv", row.names = FALSE)
cat("✓ Predictions saved to: gpr_predictions_with_uncertainty.csv\n")

# Save model
saveRDS(gpr_model, "gpr_model.rds")
cat("✓ GPR model saved to: gpr_model.rds\n")

# Save performance metrics
performance_summary <- data.frame(
  Metric = c("Accuracy", "Precision", "Recall", "F1-Score"),
  Value = c(accuracy, precision, recall, f1_score)
)
write.csv(performance_summary, "gpr_performance_metrics.csv", row.names = FALSE)
cat("✓ Performance metrics saved to: gpr_performance_metrics.csv\n")

cat("MODEL PERFORMANCE SUMMARY:\n")
print(performance_summary)

