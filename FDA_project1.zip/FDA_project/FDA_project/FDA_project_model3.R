# ============================================================================
# FMCG Supply Chain Analytics - ADVANCED PREDICTIVE MODELING
# Using Graph Neural Networks (GNN) for Late Delivery Risk Prediction
# ============================================================================
# Install required packages (run once)
# install.packages(c("tidyverse", "igraph", "torch", "ggraph", "scales", "caret"))

library(tidyverse)
library(igraph)       # Graph data structures
library(torch)        # PyTorch bindings
library(ggraph)       # Graph visualizations
library(scales)
library(caret)

cat("ADVANCED PREDICTIVE MODELING: GRAPH NEURAL NETWORK\n")

# ============================================================================
# STEP 1: LOAD AND CLEAN DATA
# ============================================================================

df_clean <- readRDS("supply_chain_cleaned.rds")
cat("✓ Data loaded successfully. Total records:", nrow(df_clean), "\n\n")

# Select relevant features
model_data <- df_clean %>%
  select(
    lead_time,
    order_item_quantity,
    late_delivery_risk,
    order_item_total,
    order_profit_per_order,
    order_region,
    category_name,
    shipping_mode,
    days_for_shipping_real_,
    days_for_shipment_scheduled_
  ) %>%
  drop_na() %>%
  filter(across(where(is.numeric), is.finite))

cat("Records after cleaning:", nrow(model_data), "\n\n")

# Encode categorical variables
model_data <- model_data %>%
  mutate(
    region_encoded = as.numeric(factor(order_region)),
    category_encoded = as.numeric(factor(category_name)),
    shipping_encoded = as.numeric(factor(shipping_mode))
  )

# ============================================================================
# STEP 2: CREATE GRAPH STRUCTURE
# ============================================================================

cat("STEP 2: CREATING GRAPH REPRESENTATION\n")

# Each order is a node. Connect nodes with same region/category/shipping_mode
edges <- model_data %>%
  mutate(id = row_number()) %>%
  select(id, region_encoded, category_encoded, shipping_encoded) %>%
  pivot_longer(cols = c(region_encoded, category_encoded, shipping_encoded),
               names_to = "feature", values_to = "value") %>%
  group_by(feature, value) %>%
  summarize(nodes = list(id), .groups = "drop") %>%
  pull(nodes) %>%
  lapply(function(ids) t(combn(ids, 2))) %>%
  do.call(rbind, .)

edges <- as.data.frame(edges)
colnames(edges) <- c("from", "to")
g <- graph_from_data_frame(edges, directed = FALSE)

cat("Graph created with", vcount(g), "nodes and", ecount(g), "edges\n\n")

# ============================================================================
# STEP 3: FEATURE MATRIX AND TARGET
# ============================================================================

features <- model_data %>%
  select(
    lead_time,
    days_for_shipping_real_,
    days_for_shipment_scheduled_,
    order_item_quantity,
    order_item_total,
    order_profit_per_order,
    region_encoded,
    category_encoded,
    shipping_encoded
  )

features_scaled <- as.matrix(scale(features))
target <- as.numeric(model_data$late_delivery_risk)

# Convert target to tensor
x <- torch_tensor(features_scaled, dtype = torch_float())
y <- torch_tensor(target, dtype = torch_float())

# ============================================================================
# STEP 4: TRAIN-TEST SPLIT
# ============================================================================

set.seed(123)
train_indices <- sample(1:nrow(features_scaled), size = 0.8 * nrow(features_scaled))
test_indices <- setdiff(1:nrow(features_scaled), train_indices)

x_train <- x[train_indices, ]
y_train <- y[train_indices]

x_test <- x[test_indices, ]
y_test <- y[test_indices]

# ============================================================================
# STEP 5: DEFINE SIMPLE GNN MODEL
# ============================================================================

# Using a simple 2-layer Graph Convolution Network (GCN)
gnn_model <- nn_module(
  "GNNModel",
  initialize = function(input_dim, hidden_dim, output_dim) {
    self$fc1 <- nn_linear(input_dim, hidden_dim)
    self$fc2 <- nn_linear(hidden_dim, output_dim)
    self$dropout <- nn_dropout(p = 0.3)
  },
  forward = function(x) {
    x <- self$fc1(x) %>% nnf_relu()
    x <- self$dropout(x)
    x <- self$fc2(x)
    x <- nnf_sigmoid(x)
    x
  }
)

input_dim <- ncol(features_scaled)
hidden_dim <- 32
output_dim <- 1

model <- gnn_model(input_dim, hidden_dim, output_dim)

# Optimizer and loss
optimizer <- optim_adam(model$parameters, lr = 0.01)
loss_fn <- nn_bceloss()

# ============================================================================
# STEP 6: TRAIN GNN
# ============================================================================

epochs <- 100
cat("Training GNN for", epochs, "epochs...\n")

for (epoch in 1:epochs) {
  model$train()
  optimizer$zero_grad()
  y_pred <- model(x_train)
  loss <- loss_fn(y_pred$squeeze(), y_train)
  loss$backward()
  optimizer$step()
  
  if (epoch %% 10 == 0) {
    cat("Epoch:", epoch, "Loss:", loss$item(), "\n")
  }
}

cat("✓ Training complete\n\n")

# ============================================================================
# STEP 7: PREDICTIONS AND UNCERTAINTY
# ============================================================================

model$eval()
with_no_grad({
  y_test_pred <- model(x_test)$squeeze()
})

# Convert predictions to binary
y_test_pred_binary <- ifelse(as_array(y_test_pred) > 0.5, 1, 0)
accuracy <- mean(y_test_pred_binary == as_array(y_test))
cat("Test Accuracy:", round(accuracy * 100, 2), "%\n\n")

# Uncertainty estimation: distance from 0.5
confidence <- abs(as_array(y_test_pred) - 0.5) * 2
uncertainty_level <- cut(
  confidence,
  breaks = c(0, 0.33, 0.67, 1.0),
  labels = c("High Uncertainty", "Medium Uncertainty", "High Confidence"),
  include.lowest = TRUE
)

# ============================================================================
# STEP 8: VISUALIZATION
# ============================================================================

predictions_df <- data.frame(
  actual = as_array(y_test),
  predicted_prob = as_array(y_test_pred),
  predicted_class = y_test_pred_binary,
  confidence = confidence,
  uncertainty_level = uncertainty_level,
  lead_time = model_data$lead_time[test_indices],
  region = model_data$order_region[test_indices]
)

# Uncertainty levels
viz_uncertainty <- ggplot(predictions_df, aes(x = uncertainty_level, fill = uncertainty_level)) +
  geom_bar(alpha = 0.8) +
  geom_text(stat = "count", aes(label = after_stat(count)), vjust = -0.5) +
  scale_fill_manual(values = c("High Uncertainty"="#e74c3c",
                               "Medium Uncertainty"="#f39c12",
                               "High Confidence"="#2ecc71")) +
  labs(title="GNN: Prediction Uncertainty Levels", x="Uncertainty Level", y="Count") +
  theme_minimal()

print(viz_uncertainty)
ggsave("gnn_uncertainty_levels.png", viz_uncertainty, width=12, height=7, dpi=300)

# ============================================================================
# STEP 9: SAVE MODEL & PREDICTIONS
# ============================================================================

torch_save(model, "gnn_model.pt")
write.csv(predictions_df, "gnn_predictions_with_uncertainty.csv", row.names = FALSE)
cat("✓ Model and predictions saved\n")
