
# FMCG Supply Chain Analytics - Part 3: Risk Scoring & Predictive Models

library(tidyverse)
library(ggplot2)
library(scales)
library(gridExtra)

# Load cleaned data
df_clean <- readRDS("supply_chain_cleaned.rds")

cat("✓ Data loaded successfully\n")
cat("  Total rows:", nrow(df_clean), "\n\n")


# STEP 1: DATA-DRIVEN RISK SCORING SYSTEM

cat("\n=== DEVELOPING RISK SCORING SYSTEM ===\n")

# Calculate risk metrics by SKU (Product Category)
sku_risk <- df_clean %>%
  group_by(category_name) %>%
  summarise(
    # Lead time metrics
    mean_lead_time = mean(lead_time, na.rm = TRUE),
    sd_lead_time = sd(lead_time, na.rm = TRUE),
    max_lead_time = max(lead_time, na.rm = TRUE),
    cv_lead_time = (sd_lead_time / mean_lead_time) * 100,
    
    # Delivery risk metrics
    stock_out_risk = mean(late_delivery_risk, na.rm = TRUE),
    late_orders = sum(late_delivery_risk, na.rm = TRUE),
    total_orders = n(),
    
    # Quantity metrics
    avg_order_qty = mean(order_item_quantity, na.rm = TRUE),
    sd_order_qty = sd(order_item_quantity, na.rm = TRUE),
    
    .groups = 'drop'
  ) %>%
  # Normalize metrics to 0-100 scale for risk scoring
  mutate(
    # Normalize lead time variability (CV) - higher CV = higher risk
    lead_time_var_score = (cv_lead_time / max(cv_lead_time, na.rm = TRUE)) * 100,
    
    # Normalize stock-out risk directly
    stock_out_score = stock_out_risk * 100,
    
    # Combined Risk Score (weighted average)
    risk_score = (lead_time_var_score * 0.4 + stock_out_score * 0.6),
    
    # Risk Category
    risk_category = case_when(
      risk_score >= 70 ~ "CRITICAL",
      risk_score >= 50 ~ "HIGH",
      risk_score >= 30 ~ "MEDIUM",
      TRUE ~ "LOW"
    ),
    risk_category = factor(risk_category, 
                           levels = c("LOW", "MEDIUM", "HIGH", "CRITICAL"))
  ) %>%
  arrange(desc(risk_score))

cat("\n=== TOP 10 HIGH-RISK PRODUCT CATEGORIES ===\n")
print(head(sku_risk, 10))


# Risk Score Dashboard


cat("\nVIZ 16: Creating Risk Score Dashboard...\n")

plot16 <- sku_risk %>%
  head(20) %>%  # Top 20 for readability
  ggplot(aes(x = reorder(category_name, risk_score), 
             y = risk_score, fill = risk_category)) +
  geom_col(alpha = 0.8) +
  scale_fill_manual(
    values = c("CRITICAL" = "#e74c3c", 
               "HIGH" = "#f39c12", 
               "MEDIUM" = "#f1c40f", 
               "LOW" = "#2ecc71"),
    name = "Risk Level"
  ) +
  geom_hline(yintercept = c(30, 50, 70), 
             linetype = "dashed", color = "gray50", alpha = 0.5) +
  coord_flip() +
  labs(
    title = "SKU Risk Scoring Dashboard (Top 20)",
    subtitle = "Risk Score = 40% Lead Time Variability + 60% Stock-out Risk",
    x = "Product Category",
    y = "Risk Score (0-100)"
  ) +
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 9),
    plot.title = element_text(size = 15, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    legend.position = "bottom"
  )

print(plot16)
ggsave("viz16_risk_score_dashboard.png", plot16, width = 12, height = 10, dpi = 300)


# Lead Time Variability vs Stock-out Risk Scatter


cat("VIZ 17: Lead Time Variability vs Stock-out Risk...\n")

plot17 <- sku_risk %>%
  filter(total_orders >= 50) %>%  # Filter for statistical significance
  ggplot(aes(x = lead_time_var_score, y = stock_out_score, 
             size = total_orders, color = risk_category)) +
  geom_point(alpha = 0.6) +
  geom_text(aes(label = category_name), size = 2.5, 
            position = position_jitter(width = 2, height = 2), 
            hjust = 0.5, check_overlap = TRUE) +
  scale_size_continuous(name = "Order Volume", range = c(3, 15)) +
  scale_color_manual(
    values = c("CRITICAL" = "#e74c3c", 
               "HIGH" = "#f39c12", 
               "MEDIUM" = "#f1c40f", 
               "LOW" = "#2ecc71"),
    name = "Risk Category"
  ) +
  labs(
    title = "Lead Time Variability vs Stock-out Risk",
    x = "Lead Time Variability Score",
    y = "Stock-out Risk Score",
    subtitle = "Bubble size = Order volume | Position = Risk profile"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    legend.position = "right"
  )

print(plot17)
ggsave("viz17_variability_vs_stockout.png", plot17, width = 13, height = 8, dpi = 300)


#REGIONAL RISK ANALYSIS


cat("\n=== STEP 2: REGIONAL RISK ANALYSIS ===\n")

regional_risk <- df_clean %>%
  group_by(order_region) %>%
  summarise(
    mean_lead_time = mean(lead_time, na.rm = TRUE),
    sd_lead_time = sd(lead_time, na.rm = TRUE),
    cv_lead_time = (sd_lead_time / mean_lead_time) * 100,
    stock_out_risk = mean(late_delivery_risk, na.rm = TRUE),
    total_orders = n(),
    .groups = 'drop'
  ) %>%
  mutate(
    lead_time_var_score = (cv_lead_time / max(cv_lead_time, na.rm = TRUE)) * 100,
    stock_out_score = stock_out_risk * 100,
    regional_risk_score = (lead_time_var_score * 0.4 + stock_out_score * 0.6),
    risk_category = case_when(
      regional_risk_score >= 70 ~ "CRITICAL",
      regional_risk_score >= 50 ~ "HIGH",
      regional_risk_score >= 30 ~ "MEDIUM",
      TRUE ~ "LOW"
    )
  ) %>%
  arrange(desc(regional_risk_score))

cat("\n=== REGIONAL RISK ASSESSMENT ===\n")
print(regional_risk)


# Regional Risk Heatmap


cat("\nVIZ 18: Regional Risk Scores...\n")

plot18 <- regional_risk %>%
  ggplot(aes(x = reorder(order_region, regional_risk_score), 
             y = regional_risk_score, fill = regional_risk_score)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", 
                      name = "Risk Score") +
  geom_text(aes(label = paste0(round(regional_risk_score, 1))), 
            hjust = -0.2, fontface = "bold", size = 3.5) +
  coord_flip() +
  labs(
    title = "Regional Risk Scores",
    x = "Region",
    y = "Risk Score (0-100)",
    subtitle = "Higher scores indicate greater operational risk"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.text.y = element_text(size = 9)
  )

print(plot18)
ggsave("viz18_regional_risk.png", plot18, width = 12, height = 9, dpi = 300)


# STEP 3: SUPPLIER PATH ANALYSIS


cat("\n=== STEP 3: SUPPLIER PATH ANALYSIS ===\n")

supplier_risk <- df_clean %>%
  group_by(order_country) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    sd_lead_time = sd(lead_time, na.rm = TRUE),
    stock_out_risk = mean(late_delivery_risk, na.rm = TRUE),
    total_orders = n(),
    .groups = 'drop'
  ) %>%
  filter(total_orders > 20) %>%  # Filter for meaningful volume
  mutate(
    cv_lead_time = (sd_lead_time / avg_lead_time) * 100,
    lead_time_score = (avg_lead_time / max(avg_lead_time, na.rm = TRUE)) * 100,
    variability_score = (cv_lead_time / max(cv_lead_time, na.rm = TRUE)) * 100,
    stock_out_score = stock_out_risk * 100,
    supplier_risk = (lead_time_score * 0.3 + variability_score * 0.3 + 
                       stock_out_score * 0.4)
  ) %>%
  arrange(desc(supplier_risk)) %>%
  head(15)  # Top 15 suppliers

cat("\n=== TOP 15 HIGH-RISK SUPPLIER PATHS ===\n")
print(supplier_risk)
# Top Supplier Risk Analysis
cat("\nVIZ 19: Top Supplier Risk Analysis...\n")

plot19 <- supplier_risk %>%
  ggplot(aes(x = reorder(order_country, supplier_risk), 
             y = supplier_risk, fill = supplier_risk)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#3498db", high = "#e74c3c", 
                      name = "Risk Score") +
  geom_text(aes(label = round(supplier_risk, 1)), 
            hjust = -0.2, fontface = "bold", size = 3.5) +
  coord_flip() +
  labs(
    title = "Top 15 High-Risk Supplier Paths",
    x = "Order Country",
    y = "Risk Score (0-100)",
    subtitle = "Based on lead time, variability, and delivery reliability"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.text.y = element_text(size = 9)
  )

print(plot19)
ggsave("viz19_supplier_risk.png", plot19, width = 12, height = 8, dpi = 300)


# VISUALIZATION 20: Shipping Mode Recommendation
cat("\nVIZ 20: Shipping Mode Comparison...\n")

shipping_analysis <- df_clean %>%
  group_by(shipping_mode) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    sd_lead_time = sd(lead_time, na.rm = TRUE),
    stock_out_risk = mean(late_delivery_risk, na.rm = TRUE),
    total_orders = n(),
    .groups = 'drop'
  ) %>%
  mutate(
    cv_lead_time = (sd_lead_time / avg_lead_time) * 100,
    reliability = case_when(
      stock_out_risk < 0.1 ~ "Excellent",
      stock_out_risk < 0.2 ~ "Good",
      stock_out_risk < 0.3 ~ "Fair",
      TRUE ~ "Poor"
    )
  )

plot20 <- shipping_analysis %>%
  ggplot(aes(x = avg_lead_time, y = stock_out_risk * 100, 
             size = total_orders, color = shipping_mode)) +
  geom_point(alpha = 0.7) +
  geom_label(aes(label = shipping_mode), size = 3.5, 
             position = position_jitter(width = 0.1, height = 0.5)) +
  scale_size_continuous(name = "Order Volume", range = c(5, 20)) +
  labs(
    title = "Shipping Mode Comparison",
    x = "Average Lead Time (Days)",
    y = "Stock-out Risk (%)",
    subtitle = "Optimal shipping mode: Low lead time + Low risk + High volume"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    legend.position = "bottom"
  )

print(plot20)
ggsave("viz20_shipping_mode_comparison.png", plot20, width = 12, height = 7, dpi = 300)


# STEP 4: ACTIONABLE RECOMMENDATIONS
cat("\n\n=== ACTIONABLE INSIGHTS & RECOMMENDATIONS ===\n")
cat(rep("=", 60), "\n\n")

# Critical SKUs
critical_skus <- sku_risk %>%
  filter(risk_category == "CRITICAL")

if(nrow(critical_skus) > 0) {
  cat("CRITICAL PRODUCT CATEGORIES (Immediate Action Required):\n")
  print(critical_skus %>% 
          select(category_name, risk_score, stock_out_risk, cv_lead_time) %>%
          head(10))
  cat("\nRECOMMENDATION: Increase buffer stock for these categories\n")
  cat("and negotiate with alternative suppliers for backup supply.\n\n")
}

# High-risk regions
high_regions <- regional_risk %>%
  filter(risk_category %in% c("HIGH", "CRITICAL"))

if(nrow(high_regions) > 0) {
  cat(" HIGH-RISK REGIONS:\n")
  print(high_regions %>% select(order_region, regional_risk_score))
  cat("\nRECOMMENDATION: Implement regional distribution centers\n")
  cat("or increase safety stock in these areas.\n\n")
}

# Supplier recommendations
reliable_suppliers <- supplier_risk %>%
  arrange(supplier_risk) %>%
  head(5)
print(reliable_suppliers %>% 
        select(order_country, avg_lead_time, stock_out_risk, supplier_risk))


# VISUALIZATION 21: Risk Category Distribution Summary

cat("\nVIZ 21: Risk Category Distribution Summary...\n")

# Combine all risk categories
all_risks <- bind_rows(
  sku_risk %>% 
    select(entity = category_name, risk_category, risk_score) %>%
    mutate(type = "Product"),
  regional_risk %>%
    select(entity = order_region, 
           risk_category, risk_score = regional_risk_score) %>%
    mutate(type = "Region")
)

plot21 <- all_risks %>%
  ggplot(aes(x = risk_category, fill = risk_category)) +
  geom_bar(alpha = 0.8) +
  geom_text(stat = 'count', aes(label = ..count..), 
            vjust = -0.5, fontface = "bold", size = 4) +
  scale_fill_manual(
    values = c("CRITICAL" = "#e74c3c", 
               "HIGH" = "#f39c12", 
               "MEDIUM" = "#f1c40f", 
               "LOW" = "#2ecc71")
  ) +
  facet_wrap(~type, scales = "free_y") +
  labs(
    title = "Risk Category Distribution Across Products and Regions",
    x = "Risk Category",
    y = "Count",
    fill = "Risk Level"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    legend.position = "bottom",
    strip.text = element_text(size = 12, face = "bold")
  )

print(plot21)
ggsave("viz21_risk_distribution.png", plot21, width = 12, height = 7, dpi = 300)


# VISUALIZATION 22: Buffer Stock Recommendations


cat("\nVIZ 22: Buffer Stock Recommendations...\n")

buffer_recommendations <- sku_risk %>%
  head(15) %>%
  mutate(
    # Calculate recommended buffer as % of average lead time
    buffer_days = case_when(
      risk_category == "CRITICAL" ~ ceiling(mean_lead_time * 0.5),
      risk_category == "HIGH" ~ ceiling(mean_lead_time * 0.3),
      risk_category == "MEDIUM" ~ ceiling(mean_lead_time * 0.2),
      TRUE ~ ceiling(mean_lead_time * 0.1)
    )
  )

plot22 <- buffer_recommendations %>%
  ggplot(aes(x = reorder(category_name, buffer_days), 
             y = buffer_days, fill = risk_category)) +
  geom_col(alpha = 0.8) +
  geom_text(aes(label = paste0(buffer_days, " days")), 
            hjust = -0.2, fontface = "bold", size = 3.5) +
  scale_fill_manual(
    values = c("CRITICAL" = "#e74c3c", 
               "HIGH" = "#f39c12", 
               "MEDIUM" = "#f1c40f", 
               "LOW" = "#2ecc71"),
    name = "Risk Level"
  ) +
  coord_flip() +
  labs(
    title = "Recommended Buffer Stock (Top 15 Categories)",
    subtitle = "Based on lead time and risk score",
    x = "Product Category",
    y = "Recommended Buffer Stock (Days)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5),
    axis.text.y = element_text(size = 9)
  )

print(plot22)
ggsave("viz22_buffer_recommendations.png", plot22, width = 12, height = 9, dpi = 300)

# ============================================================================
# SAVE ALL RESULTS
# ============================================================================

cat("\n=== SAVING RESULTS ===\n")

# Save risk scores
write.csv(sku_risk, "sku_risk_scores.csv", row.names = FALSE)
cat("✓ SKU risk scores saved to: sku_risk_scores.csv\n")

write.csv(regional_risk, "regional_risk_scores.csv", row.names = FALSE)
cat("✓ Regional risk scores saved to: regional_risk_scores.csv\n")

write.csv(supplier_risk, "supplier_risk_scores.csv", row.names = FALSE)
cat("✓ Supplier risk scores saved to: supplier_risk_scores.csv\n")

write.csv(buffer_recommendations, "buffer_stock_recommendations.csv", row.names = FALSE)
cat("✓ Buffer recommendations saved to: buffer_stock_recommendations.csv\n")

# Create comprehensive summary report
summary_report <- data.frame(
  Metric = c(
    "Total Product Categories Analyzed",
    "Critical Risk Products",
    "High Risk Products",
    "Total Regions Analyzed",
    "Critical Risk Regions",
    "High Risk Regions",
    "Average Lead Time (Days)",
    "Average Stock-out Risk (%)",
    "Most Reliable Shipping Mode",
    "Highest Risk Region"
  ),
  Value = c(
    nrow(sku_risk),
    sum(sku_risk$risk_category == "CRITICAL"),
    sum(sku_risk$risk_category == "HIGH"),
    nrow(regional_risk),
    sum(regional_risk$risk_category == "CRITICAL"),
    sum(regional_risk$risk_category == "HIGH"),
    round(mean(df_clean$lead_time, na.rm = TRUE), 2),
    round(mean(df_clean$late_delivery_risk, na.rm = TRUE) * 100, 2),
    shipping_analysis %>% 
      arrange(stock_out_risk) %>% 
      slice(1) %>% 
      pull(shipping_mode),
    regional_risk %>% 
      slice_max(regional_risk_score, n = 1) %>% 
      pull(order_region)
  )
)

write.csv(summary_report, "risk_analysis_summary_report.csv", row.names = FALSE)
cat("✓ Summary report saved to: risk_analysis_summary_report.csv\n")

cat("KEY FINDINGS:\n")
cat("  • Total Product Categories:", nrow(sku_risk), "\n")
cat("  • Critical Risk Products:", sum(sku_risk$risk_category == "CRITICAL"), "\n")
cat("  • High Risk Regions:", sum(regional_risk$risk_category == "HIGH"), "\n")
cat("  • Average Stock-out Risk:", 
    round(mean(df_clean$late_delivery_risk, na.rm = TRUE) * 100, 2), "%\n\n")