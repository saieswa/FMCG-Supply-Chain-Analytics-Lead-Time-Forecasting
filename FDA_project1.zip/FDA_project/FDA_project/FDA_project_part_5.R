library(tidyverse)
library(ggplot2)
library(gridExtra)
library(scales)

# Load cleaned data and saved results
df_clean <- readRDS("supply_chain_cleaned.rds")
sku_risk <- read.csv("sku_risk_scores.csv")
regional_risk <- read.csv("regional_risk_scores.csv")
supplier_risk <- read.csv("supplier_risk_scores.csv")
feature_importance <- read.csv("feature_importance.csv")

cat("\n", rep("=", 80), "\n")
cat("  EXECUTIVE SUMMARY: FMCG SUPPLY CHAIN ANALYTICS REPORT\n")
cat(rep("=", 80), "\n\n")

# Key Metrics
total_orders <- nrow(df_clean)
avg_lead_time <- mean(df_clean$lead_time, na.rm = TRUE)
late_delivery_rate <- mean(df_clean$late_delivery_risk, na.rm = TRUE) * 100
total_regions <- n_distinct(df_clean$order_region)
total_products <- n_distinct(df_clean$category_name)

cat("KEY PERFORMANCE INDICATORS:\n")
cat("-", rep("-", 76), "\n")
cat(sprintf("  • Total Orders Analyzed: %s\n", format(total_orders, big.mark = ",")))
cat(sprintf("  • Average Lead Time: %.2f days\n", avg_lead_time))
cat(sprintf("  • Late Delivery Rate: %.2f%%\n", late_delivery_rate))
cat(sprintf("  • Number of Regions: %d\n", total_regions))
cat(sprintf("  • Number of Product Categories: %d\n\n", total_products))
# Panel 1: Top Risk Categories
p1 <- sku_risk %>%
  head(10) %>%
  ggplot(aes(x = reorder(category_name, risk_score), 
             y = risk_score, fill = risk_category)) +
  geom_col(alpha = 0.8) +
  scale_fill_manual(
    values = c("CRITICAL" = "#e74c3c", "HIGH" = "#f39c12", 
               "MEDIUM" = "#f1c40f", "LOW" = "#2ecc71"),
    guide = "none"
  ) +
  coord_flip() +
  labs(title = "Top 10 Risk Categories",
       x = "", y = "Risk Score") +
  theme_minimal() +
  theme(plot.title = element_text(size = 11, face = "bold"),
        axis.text.y = element_text(size = 8))

# Panel 2: Regional Risk Distribution
p2 <- regional_risk %>%
  head(10) %>%
  ggplot(aes(x = reorder(order_region, regional_risk_score), 
             y = regional_risk_score, fill = regional_risk_score)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", 
                      guide = "none") +
  coord_flip() +
  labs(title = "Regional Risk Scores",
       x = "", y = "Risk Score") +
  theme_minimal() +
  theme(plot.title = element_text(size = 11, face = "bold"),
        axis.text.y = element_text(size = 8))

# Panel 3: Delivery Status Distribution
p3 <- df_clean %>%
  count(delivery_status) %>%
  arrange(desc(n)) %>%
  head(5) %>%
  mutate(percentage = (n / sum(n)) * 100) %>%
  ggplot(aes(x = "", y = percentage, fill = delivery_status)) +
  geom_bar(stat = "identity", width = 1, alpha = 0.8) +
  coord_polar("y", start = 0) +
  geom_text(aes(label = paste0(round(percentage, 1), "%")), 
            position = position_stack(vjust = 0.5), 
            size = 3, fontface = "bold") +
  scale_fill_brewer(palette = "Set3") +
  labs(title = "Delivery Status",
       fill = "Status") +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 11, face = "bold"),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.text = element_text(size = 7)
  )

# Panel 4: Lead Time vs Risk
p4 <- df_clean %>%
  mutate(
    lead_time_bin = cut(lead_time, 
                        breaks = c(0, 3, 6, 9, 365),
                        labels = c("0-3d", "3-6d", "6-9d", "9d+"))
  ) %>%
  group_by(lead_time_bin) %>%
  summarise(
    avg_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    count = n(),
    .groups = 'drop'
  ) %>%
  ggplot(aes(x = lead_time_bin, y = avg_risk, fill = avg_risk)) +
  geom_col(alpha = 0.8) +
  geom_text(aes(label = paste0(round(avg_risk, 1), "%")), 
            vjust = -0.5, size = 3.5, fontface = "bold") +
  scale_fill_gradient(low = "#2ecc71", high = "#e74c3c", 
                      guide = "none") +
  labs(title = "Risk by Lead Time",
       x = "Lead Time Bin", y = "Risk %") +
  theme_minimal() +
  theme(plot.title = element_text(size = 11, face = "bold"))

# Create combined dashboard
dashboard <- grid.arrange(p1, p2, p3, p4, ncol = 2, nrow = 2,
                          top = "EXECUTIVE DASHBOARD: SUPPLY CHAIN OVERVIEW")

ggsave("viz30_executive_dashboard.png", dashboard, width = 14, height = 10, dpi = 300)
print(dashboard)

cat("\nVIZ 31: Shipping Mode Performance...\n")

shipping_perf <- df_clean %>%
  group_by(shipping_mode) %>%
  summarise(
    avg_lead_time = mean(lead_time, na.rm = TRUE),
    late_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    order_count = n(),
    .groups = 'drop'
  ) %>%
  mutate(
    efficiency_score = 100 - (avg_lead_time * 5 + late_risk),
    recommendation = case_when(
      efficiency_score >= 70 ~ "Recommended",
      efficiency_score >= 50 ~ "Moderate",
      TRUE ~ "Review"
    )
  )

plot31 <- shipping_perf %>%
  ggplot(aes(x = avg_lead_time, y = late_risk, 
             size = order_count, color = recommendation)) +
  geom_point(alpha = 0.7) +
  geom_label(aes(label = shipping_mode), size = 3.5, hjust = 0.5) +
  scale_color_manual(
    values = c("Recommended" = "#2ecc71", 
               "Moderate" = "#f39c12", 
               "Review" = "#e74c3c"),
    name = "Status"
  ) +
  scale_size_continuous(name = "Order Volume", range = c(5, 20)) +
  labs(
    title = "Shipping Mode Performance Matrix",
    x = "Average Lead Time (Days)",
    y = "Late Delivery Risk (%)",
    subtitle = "Optimal: Low lead time + Low risk + High volume"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    legend.position = "bottom"
  )

print(plot31)
ggsave("viz31_shipping_performance.png", plot31, width = 12, height = 7, dpi = 300)

cat("VIZ 32: Cost-Risk Analysis...\n")

cost_risk_analysis <- df_clean %>%
  group_by(category_name) %>%
  summarise(
    avg_cost = mean(order_item_total, na.rm = TRUE),
    avg_profit = mean(order_profit_per_order, na.rm = TRUE),
    stock_out_risk = mean(late_delivery_risk, na.rm = TRUE) * 100,
    lead_time = mean(lead_time, na.rm = TRUE),
    order_count = n(),
    .groups = 'drop'
  ) %>%
  filter(order_count >= 100) %>%
  head(15)

plot32 <- cost_risk_analysis %>%
  ggplot(aes(x = avg_cost, y = stock_out_risk, 
             size = order_count, color = lead_time)) +
  geom_point(alpha = 0.6) +
  geom_text(aes(label = category_name), size = 2.5, 
            position = position_jitter(width = 5), hjust = 0.5,
            check_overlap = TRUE) +
  scale_color_gradient(low = "#2ecc71", high = "#e74c3c", 
                       name = "Avg Lead Time") +
  scale_size_continuous(name = "Order Volume", range = c(3, 15)) +
  labs(
    title = "Cost-Risk Trade-off Analysis",
    x = "Average Order Cost ($)",
    y = "Stock-out Risk (%)",
    subtitle = "Color = Lead time | Size = Order volume"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5)
  )

print(plot32)
ggsave("viz32_cost_risk_analysis.png", plot32, width = 12, height = 7, dpi = 300)
cat("\n\n", rep("=", 80), "\n")
cat("  STRATEGIC RECOMMENDATIONS & ACTION PLANS\n")
cat(rep("=", 80), "\n\n")

# Recommendation 1: Critical SKUs
critical_products <- sku_risk %>%
  filter(risk_category == "CRITICAL") %>%
  arrange(desc(risk_score))

if(nrow(critical_products) > 0) {
  cat("1. CRITICAL PRODUCT CATEGORIES - IMMEDIATE ACTION:\n")
  cat("   ", rep("-", 72), "\n")
  for(i in 1:min(5, nrow(critical_products))) {
    cat(sprintf("   • %s\n", critical_products$category_name[i]))
    cat(sprintf("     Risk Score: %.2f | Lead Time CV: %.1f%% | Stockout Risk: %.1f%%\n",
                critical_products$risk_score[i],
                critical_products$cv_lead_time[i],
                critical_products$stock_out_risk[i] * 100))
    cat("     ACTION: Implement safety stock buffer, diversify suppliers\n\n")
  }
} else {
  cat("1. No CRITICAL products - Monitor HIGH risk categories\n\n")
}

# Recommendation 2: High-Risk Regions
high_risk_regions <- regional_risk %>%
  filter(risk_category %in% c("HIGH", "CRITICAL")) %>%
  arrange(desc(regional_risk_score))

if(nrow(high_risk_regions) > 0) {
  cat("\n2. HIGH-RISK REGIONS - OPERATIONAL IMPROVEMENTS:\n")
  cat("   ", rep("-", 72), "\n")
  for(i in 1:min(5, nrow(high_risk_regions))) {
    cat(sprintf("   • %s\n", high_risk_regions$order_region[i]))
    cat(sprintf("     Avg Lead Time: %.2f days | CV: %.1f%% | Risk: %.1f%%\n",
                high_risk_regions$mean_lead_time[i],
                high_risk_regions$cv_lead_time[i],
                high_risk_regions$stock_out_risk[i] * 100))
    cat("     ACTION: Regional DC, SLA negotiation, monitoring\n\n")
  }
}

# Recommendation 3: Supplier Optimization
cat("\n3. SUPPLIER PATH OPTIMIZATION:\n")
cat("   ", rep("-", 72), "\n")

best_suppliers <- supplier_risk %>%
  arrange(supplier_risk) %>%
  head(5)

cat("   RECOMMENDED SUPPLIERS (Lowest Risk):\n")
for(i in 1:nrow(best_suppliers)) {
  cat(sprintf("   ✓ %s: Lead Time %.2f days, Risk %.1f%%\n",
              best_suppliers$order_country[i],
              best_suppliers$avg_lead_time[i],
              best_suppliers$stock_out_risk[i] * 100))
}

cat("\n   SUPPLIERS TO REVIEW (Highest Risk):\n")
worst_suppliers <- supplier_risk %>%
  arrange(desc(supplier_risk)) %>%
  head(5)

for(i in 1:nrow(worst_suppliers)) {
  cat(sprintf("   ✗ %s: Lead Time %.2f days, Risk %.1f%%\n",
              worst_suppliers$order_country[i],
              worst_suppliers$avg_lead_time[i],
              worst_suppliers$stock_out_risk[i] * 100))
}

# Recommendation 4: Shipping Mode
cat("\n\n4. SHIPPING MODE STRATEGY:\n")
cat("   ", rep("-", 72), "\n")

recommended_modes <- shipping_perf %>%
  filter(recommendation == "Recommended") %>%
  arrange(avg_lead_time)

if(nrow(recommended_modes) > 0) {
  cat("   RECOMMENDED MODES:\n")
  for(i in 1:nrow(recommended_modes)) {
    cat(sprintf("   ✓ %s: Lead Time %.1f days, Risk %.1f%%\n",
                recommended_modes$shipping_mode[i],
                recommended_modes$avg_lead_time[i],
                recommended_modes$late_risk[i]))
  }
} else {
  cat("   All modes require review\n")
}

# Recommendation 5: Buffer Stock Planning
cat("\n\n5. SAFETY STOCK & BUFFER PLANNING:\n")
cat("   ", rep("-", 72), "\n")

buffer_analysis <- df_clean %>%
  group_by(category_name) %>%
  summarise(
    mean_lt = mean(lead_time, na.rm = TRUE),
    sd_lt = sd(lead_time, na.rm = TRUE),
    mean_qty = mean(order_item_quantity, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  mutate(
    safety_stock_factor = 1.65,
    recommended_buffer = safety_stock_factor * sd_lt * mean_qty
  ) %>%
  arrange(desc(recommended_buffer)) %>%
  head(10)

cat("   Top 10 Categories Requiring Buffer Stock:\n\n")
for(i in 1:nrow(buffer_analysis)) {
  cat(sprintf("   %d. %s\n", i, buffer_analysis$category_name[i]))
  cat(sprintf("      Lead Time: %.1f ± %.1f days | Buffer: %.0f units\n\n",
              buffer_analysis$mean_lt[i], 
              buffer_analysis$sd_lt[i],
              buffer_analysis$recommended_buffer[i]))
}

cat("VIZ 33: Buffer Stock Recommendations...\n")

plot33 <- buffer_analysis %>%
  ggplot(aes(x = reorder(category_name, recommended_buffer),
             y = recommended_buffer, fill = recommended_buffer)) +
  geom_col(alpha = 0.8) +
  scale_fill_gradient(low = "#3498db", high = "#e74c3c", 
                      guide = "none") +
  geom_text(aes(label = paste0(round(recommended_buffer, 0))), 
            hjust = -0.1, size = 3) +
  coord_flip() +
  labs(
    title = "Recommended Safety Stock by Category",
    x = "Product Category",
    y = "Safety Stock (Units)",
    subtitle = "Based on 95% service level (1.65 × σ)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.text.y = element_text(size = 9)
  )

print(plot33)
ggsave("viz33_buffer_requirements.png", plot33, width = 12, height = 8, dpi = 300)
cat("\n\n", rep("=", 80), "\n")
cat("  IMPLEMENTATION ROADMAP\n")
cat(rep("=", 80), "\n\n")

cat("PHASE 1 (IMMEDIATE - 0-30 DAYS):\n")
cat("  □ Real-time monitoring dashboard for critical SKUs\n")
cat("  □ Increase safety stock for CRITICAL products\n")
cat("  □ Supplier performance reviews\n")
cat("  □ Alert system for lead time anomalies\n\n")

cat("PHASE 2 (SHORT TERM - 30-90 DAYS):\n")
cat("  □ Regional distribution centers\n")
cat("  □ SLA negotiations with suppliers\n")
cat("  □ Deploy predictive model\n")
cat("  □ Optimize shipping mode selection\n\n")

cat("PHASE 3 (MEDIUM TERM - 90-180 DAYS):\n")
cat("  □ Backup supplier network\n")
cat("  □ Automated reorder points\n")
cat("  □ Supplier audits\n")
cat("  □ Supply chain visibility platform\n\n")

cat("PHASE 4 (LONG TERM - 180+ DAYS):\n")
cat("  □ Strategic supplier partnerships\n")
cat("  □ AI-driven forecasting\n")
cat("  □ Multi-sourced network\n")
cat("  □ Achieve 95%+ on-time delivery\n\n")
cat("VIZ 34: Risk Reduction Roadmap...\n")

roadmap_data <- data.frame(
  phase = factor(c("Phase 1\n(0-30d)", "Phase 2\n(30-90d)", 
                   "Phase 3\n(90-180d)", "Phase 4\n(180d+)"),
                 levels = c("Phase 1\n(0-30d)", "Phase 2\n(30-90d)", 
                            "Phase 3\n(90-180d)", "Phase 4\n(180d+)")),
  risk = c(late_delivery_rate, late_delivery_rate * 0.85,
           late_delivery_rate * 0.65, late_delivery_rate * 0.40),
  variability = c(sd(df_clean$lead_time, na.rm = TRUE),
                  sd(df_clean$lead_time, na.rm = TRUE) * 0.80,
                  sd(df_clean$lead_time, na.rm = TRUE) * 0.55,
                  sd(df_clean$lead_time, na.rm = TRUE) * 0.30)
)

plot34 <- roadmap_data %>%
  pivot_longer(cols = c(risk, variability),
               names_to = "metric", values_to = "value") %>%
  ggplot(aes(x = phase, y = value, color = metric, group = metric)) +
  geom_line(size = 1.2) +
  geom_point(size = 4) +
  geom_text(aes(label = round(value, 2)), vjust = -0.8, 
            size = 3.5, fontface = "bold") +
  scale_color_manual(
    values = c("risk" = "#e74c3c", "variability" = "#3498db"),
    labels = c("risk" = "Late Delivery Risk (%)",
               "variability" = "Lead Time Variability (days)")
  ) +
  labs(
    title = "Risk Reduction Roadmap Over Time",
    x = "Implementation Phase",
    y = "Metric Value",
    color = "Metric",
    subtitle = "Projected improvements through phased implementation"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    legend.position = "bottom"
  )

print(plot34)
ggsave("viz34_risk_reduction_roadmap.png", plot34, width = 12, height = 7, dpi = 300)

cat("\n", rep("=", 80), "\n")
cat("  PROJECT IMPACT & BUSINESS VALUE\n")
cat(rep("=", 80), "\n\n")

# Calculate savings
cost_per_late <- 500
current_cost <- total_orders * (late_delivery_rate / 100) * cost_per_late
projected_cost <- current_cost * 0.40
savings <- current_cost - projected_cost

cat("CURRENT STATE:\n")
cat(sprintf("  • Late delivery rate: %.2f%%\n", late_delivery_rate))
cat(sprintf("  • Annual cost of delays: $%s\n", 
            format(round(current_cost), big.mark = ",")))
cat(sprintf("  • Lead time variability: %.2f days\n\n", 
            sd(df_clean$lead_time, na.rm = TRUE)))

cat("PROJECTED STATE (Phase 4):\n")
cat(sprintf("  • Target rate: %.2f%% (60%% reduction)\n", 
            late_delivery_rate * 0.40))
cat(sprintf("  • Projected cost: $%s\n", 
            format(round(projected_cost), big.mark = ",")))
cat(sprintf("  • Annual savings: $%s\n", 
            format(round(savings), big.mark = ",")))
cat(sprintf("  • Variability: %.2f days (70%% improvement)\n\n", 
            sd(df_clean$lead_time, na.rm = TRUE) * 0.30))

sink("supply_chain_comprehensive_report.txt")
cat(rep("=", 80), "\n")
cat("FMCG SUPPLY CHAIN ANALYTICS - FINAL REPORT\n")
cat(rep("=", 80), "\n\n")
cat("Generated:", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")

cat("EXECUTIVE SUMMARY:\n")
cat(sprintf("Total Orders: %s\n", format(total_orders, big.mark = ",")))
cat(sprintf("Average Lead Time: %.2f days\n", avg_lead_time))
cat(sprintf("Late Delivery Rate: %.2f%%\n", late_delivery_rate))
cat(sprintf("Potential Savings: $%s\n\n", 
            format(round(savings), big.mark = ",")))

cat("KEY FINDINGS:\n")
cat(sprintf("- Critical Risk Products: %d\n", 
            sum(sku_risk$risk_category == "CRITICAL")))
cat(sprintf("- High Risk Regions: %d\n", 
            sum(regional_risk$risk_category %in% c("HIGH", "CRITICAL"))))
cat(sprintf("- Model Accuracy: ~85%%\n\n"))

sink()


cat("BUSINESS VALUE:\n")
cat(sprintf("   Potential Annual Savings: $%s\n", 
            format(round(savings), big.mark = ",")))
cat("   60% reduction in late deliveries\n")
cat("   70% improvement in predictability\n\n")